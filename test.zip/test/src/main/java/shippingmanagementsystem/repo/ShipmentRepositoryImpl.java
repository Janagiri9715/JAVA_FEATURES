package shippingmanagementsystem.repo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import shippingmanagementsystem.entity.Shipment;

public class ShipmentRepositoryImpl {

	public Set<Shipment> shipments = new HashSet();

	// singleton starts

	private ShipmentRepositoryImpl() {

	}

	private static ShipmentRepositoryImpl shipmentRepositoryImpl;

	public static ShipmentRepositoryImpl getShipmentRepositoryImpl() {
		if (shipmentRepositoryImpl == null) {
			shipmentRepositoryImpl = new ShipmentRepositoryImpl();
		}
		return shipmentRepositoryImpl;

	}

	// singleton ends

	public Shipment addUser(Shipment shipment) {
		boolean result = shipments.add(shipment);
		if (result) {
			return shipment;
		}
		return null;
	}

	public Optional<Shipment> getUserById(int id) {

		// UUID uuid = UUID.fromString(id);
		// Case :4
		return shipments.stream().filter(e -> e.getId() == id).findFirst();
		// Case :1
		// Consumer<Shipment> consumer = e -> System.out.println("1010101010 :: " + e);
		// shipments.forEach(consumer);
		// Case :2
		// Shipment shipmentResult=null;
		// AtomicReference<Shipment> atomicreference = new AtomicReference<>();
		// Consumer<Shipment> consumer = e -> {if(e.getUserId().equals(id)) {
		// atomicreference.set(e);
		// }
		// };
		// shipments.forEach(consumer);
		//
		// return Optional.ofNullable(atomicreference.get());
		// Case :3
		// for (Shipment shipment : shipments) {
		// if (shipment.getUserId().equals(uuid)) {
		// return Optional.of(shipment);
		// }
		// }
		// return Optional.empty();
	}

	public Optional<List<Shipment>> getUsers() {

		if (shipments.isEmpty()) {
			return Optional.empty();
		} else {
			// return Optional.of(shipments);
			return Optional.of(new ArrayList<>(shipments));
		}
	}

	public void deleteUser(int id) {
		// UUID uuid = UUID.fromString(id);

		for (Shipment shipment : shipments) {
			System.out.println("shipment :: " + shipment.getId() + " id:: " + id);
			if (shipment.getId() == id) {
				shipments.remove(shipment);
			}
		}

	}

	public Shipment updateUser(int id, Shipment shipment) {

		for (Shipment shipment1 : shipments) {
			if (shipment1.getId() == id) {

				shipment1.setAssignedDriver("Jana");
				return shipment1;
			}
		}

		return shipment;
	}

}

