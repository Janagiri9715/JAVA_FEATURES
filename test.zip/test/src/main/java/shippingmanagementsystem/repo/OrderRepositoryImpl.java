package shippingmanagementsystem.repo;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import shippingmanagementsystem.entity.Order;

public class OrderRepositoryImpl {

	public Set<Order> orders = new HashSet();

	// singleton starts

	private OrderRepositoryImpl() {

	}

	private static OrderRepositoryImpl orderRepositoryImpl;

	public static OrderRepositoryImpl getOrderRepositoryImpl() {
		if (orderRepositoryImpl == null) {
			orderRepositoryImpl = new OrderRepositoryImpl();
		}
		return orderRepositoryImpl;

	}

	// singleton ends

	public Order addUser(Order order) {
		boolean result = orders.add(order);
		if (result) {
			return order;
		}
		return null;
	}

	public Optional<Order> getUserById(int id) {

		// UUID uuid = UUID.fromString(id);
		// Case :4
		return orders.stream().filter(e -> e.getId() == id).findFirst();
		// Case :1
		// Consumer<Order> consumer = e -> System.out.println("1010101010 :: " + e);
		// orders.forEach(consumer);
		// Case :2
		// Order orderResult=null;
		// AtomicReference<Order> atomicreference = new AtomicReference<>();
		// Consumer<Order> consumer = e -> {if(e.getUserId().equals(id)) {
		// atomicreference.set(e);
		// }
		// };
		// orders.forEach(consumer);
		//
		// return Optional.ofNullable(atomicreference.get());
		// Case :3
		// for (Order order : orders) {
		// if (order.getUserId().equals(uuid)) {
		// return Optional.of(order);
		// }
		// }
		// return Optional.empty();
	}

	public Optional<List<Order>> getUsers() {

		if (orders.isEmpty()) {
			return Optional.empty();
		} else {
			// return Optional.of(orders);
			return Optional.of(new ArrayList<>(orders));
		}
	}

	public void deleteUser(int id) {
		// UUID uuid = UUID.fromString(id);

		for (Order order : orders) {
			System.out.println("order :: " + order.getId() + " id:: " + id);
			if (order.getId() == id) {
				orders.remove(order);
			}
		}

	}

	public Order updateUser(int id, Order order) {

		for (Order order1 : orders) {
			if (order1.getId() == id) {

				order1.setCustomer("JANA");
				return order1;
			}
		}

		return order;
	}

}

