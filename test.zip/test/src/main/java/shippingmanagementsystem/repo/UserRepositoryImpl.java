package shippingmanagementsystem.repo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.testing.user.UserDetail;


public class UserRepositoryImpl {

	public Set<UserDetail> users = new HashSet();

	// singleton starts

	private UserRepositoryImpl() {

	}

	private static UserRepositoryImpl userRepositoryImpl;

	public static UserRepositoryImpl getUserRepositoryImpl() {
		if (userRepositoryImpl == null) {
			userRepositoryImpl = new UserRepositoryImpl();
		}
		return userRepositoryImpl;

	}

	// singleton ends


	public UserDetail addUser(UserDetail user) {
		boolean result = users.add(user);
		if (result) {
			return user;
		}
		return null;
	}


	public Optional<UserDetail> getUserById(String id) {

		UUID uuid = UUID.fromString(id);
		// Case :4
		return users.stream().filter(e -> e.getUserId().equals(id)).findFirst();
		// Case :1
//		Consumer<UserDetail> consumer = e -> System.out.println("1010101010 :: " + e);		
//		users.forEach(consumer);
		// Case :2
		// UserDetail userResult=null;
		// AtomicReference<UserDetail> atomicreference = new AtomicReference<>();
		// Consumer<UserDetail> consumer = e -> {if(e.getUserId().equals(id)) {
		// atomicreference.set(e);
		// }
		// };
// users.forEach(consumer);
		//
		// return Optional.ofNullable(atomicreference.get());
		// Case :3
		// for (UserDetail user : users) {
		// if (user.getUserId().equals(uuid)) {
		// return Optional.of(user);
		// }
		// }
		// return Optional.empty();
	}


	public Optional<List<UserDetail>> getUsers() {

		if (users.isEmpty()) {
			return Optional.empty();
		} else {
			// return Optional.of(users);
			return Optional.of(new ArrayList<>(users));
		}
	}


	public void deleteUser(String id) {
		// UUID uuid = UUID.fromString(id);

		for (UserDetail user : users) {
			System.out.println("user :: " + user.getUserId() + " id:: " + id);
			if (user.getUserId().equals(id)) {
				users.remove(user);
			}
		}


	}


	public UserDetail updateUser(String id, UserDetail user) {

		for (UserDetail user1 : users) {
			if (user1.getUserId().equals(id)) {

				user1.setUserName("JANA");
				return user1;
			}
		}

		return user;
	}

}
