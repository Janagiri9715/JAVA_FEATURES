package com.testing;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class LambaExpressionDemo4 {

	public static void main(String[] args) {

		IOps1 ii = (int a, int b) -> a + b;
		int res = ii.add(20, 10);
		System.out.println(res);
//		demo((int a, int b) -> a + b + 20);
		demo();

		IOps iOps = new IOps() {

			@Override
			public int add(int a, int b) {
				return a + b;
			}
		};

	}

	// public static void demo(IOps iOps) {
	// System.out.println(iOps.add(200, 100));
	// }
	public static void demo() {
		Map<String, Integer> map = new HashMap<>();
		map.put("A", 10);
		map.put("B", 20);
		map.put("C", 30);
		map.put("D", 40);
		map.put("E", 50);
		map.put("F", 60);

		Function<String, Integer> function = x -> x.length();
		Function<Integer, Integer> fun2 = x -> x * 2;

		int res = function.andThen(fun2).apply("Jana");

		System.out.println(res);

		// case 1 :
		// Function<String, Integer> function = x -> x.length();
		// System.out.println(function.apply("Jana"));

		// Function<String, Integer> function = x -> x.length();
		// System.out.println(function.apply("Jana"));

		// new one

		// map.forEach((k, v) -> {
		// System.out.println(k + " " + v);
		// });
		// old one :
		// for(Map.Entry<String, Integer> entry:map.entrySet())
		// {
		//
		// System.out.println("Key : " + entry.getKey() + ", value" + entry.getValue());
		// }
}

}

@FunctionalInterface
interface IOps1 {

	public int add(int a, int b);

}
