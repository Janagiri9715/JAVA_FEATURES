package com.testing.test;


public class Concret extends AbstractTest {

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		System.out.println("Method 1 Executed");
	}

	@Override
	public void method8() {
		// TODO Auto-generated method stub
		System.out.println("Method 8 Executed");
	}

	@Override
	public void method9() {
		// TODO Auto-generated method stub
		System.out.println("Method 9 Executed");
	}

	public void method10() {

	}

}
