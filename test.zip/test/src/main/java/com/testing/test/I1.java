package com.testing.test;


public interface I1 {

	public void method1();

	public void method2();

	public void method3();

	public void method4();

}
