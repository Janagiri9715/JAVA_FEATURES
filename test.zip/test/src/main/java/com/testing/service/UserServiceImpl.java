package com.testing.service;

import java.util.List;
import java.util.Optional;

import com.testing.repo.UserRepository;
import com.testing.repo.UserRepositoryImpl;
import com.testing.user.UserDetail;


public class UserServiceImpl implements UserService {

	private UserRepository userRepository = UserRepositoryImpl.getUserRepositoryImpl();

	private static UserServiceImpl userServiceImpl;

	private UserServiceImpl() {

	}



	public static UserServiceImpl getUserServiceImpl() {
		if (userServiceImpl == null) {
			userServiceImpl = new UserServiceImpl();
		}
		return userServiceImpl;

	}

	@Override
	public UserDetail addUser(UserDetail user) {
		// TODO Auto-generated method stub
		return userRepository.addUser(user);
	}

	@Override
	public Optional<UserDetail> getUserById(String id) {
		// TODO Auto-generated method stub
		// return Optional.empty();
		return userRepository.getUserById(id);
	}

	@Override
	public Optional<List<UserDetail>> getUsers() {
		// TODO Auto-generated method stub
		return userRepository.getUsers();
	}

	@Override
	public void deleteUser(String id) {
		userRepository.deleteUser(id);

	}

	@Override
	public UserDetail updateUser(String id, UserDetail user) {
		// TODO Auto-generated method stub
		return userRepository.updateUser(id, user);
	}

}
