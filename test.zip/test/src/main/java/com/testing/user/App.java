package com.testing.user;

import java.util.List;
import java.util.Optional;

import com.testing.service.UserService;
import com.testing.service.UserServiceImpl;

public class App {

	public static void main(String[] args) {
		UserService userService = UserServiceImpl.getUserServiceImpl();
		UserDetail u = null;
		try {
			u = new UserDetail("janagiri", "Password123", "Mani", "Dhana", "857412369", "abc@gmail.com");

			// System.out.println("UUUUU " + u.UserId);
			// userService.addUser(u);
			// userService.addUser(u);
			//
			//
			//
			// if (userService != null) {
			// System.out.println("User Added Successfully");
			//
			// }

			usingCase("Add", u, userService);

			// userService.getUserById(u.UserId);

			// Optional<UserDetail> userDetailOptional = userService.getUserById(u.UserId);
			//
			// System.out.println("Enter into User ID Successfully" + userDetailOptional);
			// if (userDetailOptional.isPresent()) {
			// System.out.println("Enter into User ID Successfully");
			// }
			usingCase("GetUserById", u, userService);

			// Optional<List<UserDetail>> getUsers = userService.getUsers();
			//
			// if (getUsers != null) {
			// for (UserDetail userList : getUsers.get()) {
			// System.out.println("User name is : " + userList.getUserName());
			// }
			// System.out.println("Getting User Successfully");
			// }

			usingCase("GetUser", u, userService);

			// UserDetail userDetail = userService.updateUser(u.UserId, u);
			// System.out.println("u.UserId :: " + u.UserId);
			// if (userDetail != null) {
			// System.out.println("User Updated Successfully " + userDetail);
			// }
			usingCase("UpdateUser", u, userService);

			// userService.deleteUser(u.UserId.toString());
			usingCase("DeleteUser", u, userService);

		} catch (InvalidNameException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void usingCase(String ss, UserDetail u, UserService userService) {

		switch (ss) {
			case "Add":
				System.out.println("UUUUU " + u.UserId);
				userService.addUser(u);
				userService.addUser(u);

				if (userService != null) {
					System.out.println("User Added Successfully");

				}
				break;
			case "GetUserById":
				Optional<UserDetail> userDetailOptional = userService.getUserById(u.UserId);

				System.out.println("Enter into User ID Successfully" + userDetailOptional);
				if (userDetailOptional.isPresent()) {
					System.out.println("Enter into User ID Successfully");
				}
				break;
			case "GetUser":
				Optional<List<UserDetail>> getUsers = userService.getUsers();

				if (getUsers != null) {
					for (UserDetail userList : getUsers.get()) {
						System.out.println("User name is : " + userList.getUserName());
					}
					System.out.println("Getting User Successfully");
				}
				break;
			case "UpdateUser":
				UserDetail userDetail = userService.updateUser(u.UserId, u);
				System.out.println("u.UserId :: " + u.UserId);
				if (userDetail != null) {
					System.out.println("User Updated Successfully " + userDetail);
				}
				break;
			case "DeleteUser":
				userService.deleteUser(u.UserId.toString());
				System.out.println("User Delete Successfully ");
				break;
		}

	}

}
