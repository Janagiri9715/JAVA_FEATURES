package com.testing.user;

import java.util.UUID;

public class UserDetail extends InvalidNameException {

	public String UserId;
	public String UserName;
	public String Password;
	public String FirstName;
	public String LastName;
	public String ContactNumber;
	public String emailId;

	public UserDetail(
			String userName,
			String password,
			String firstName,
			String lastName,
			String contactNumber,
			String emailId) throws InvalidNameException {
		this.UserId = UUID.randomUUID().toString();
		setUserName(userName);
		setPassword(password);
		setFirstName(firstName);
		setLastName(lastName);
		setContactNumber(contactNumber);
		setEmailId(emailId);
	}

	public String getUserId() {
		return UserId;
	}

	public String getUserName() {
		return UserName;
	}

	public String getPassword() {
		return Password;
	}

	public String getFirstName() {
		return FirstName;
	}

	public String getLastName() {
		return LastName;
	}

	public String getContactNumber() {
		return ContactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setUserId(String userId) {
		UserId = UUID.randomUUID().toString();
	}

	public void setUserName(String userName) {
		if (userName != null && userName.length() <= 8) {
			UserName = userName;
			System.out.println("If part works in user name");
		} else {
			System.out.println("ELSE part works in user name");
			// this.toString();
			// getMessage();
			throw new IllegalArgumentException("UserName Size Greater than 8");
		}

	}

	public void setPassword(String password) throws InvalidNameException {
		String contactPattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)[A-Za-z\\d]{8,}$";
		if (password != null && password.matches(contactPattern)) {
			Password = password;
		} else {
			// getMessage();
			throw new IllegalArgumentException("Password not Valid");
		}

	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public void setContactNumber(String contactNumber) {
		String contactPattern = "^\\d{10}$";
		if (contactNumber != null && contactNumber.matches(contactPattern)) {
			ContactNumber = contactNumber;
		} else {
			new IllegalArgumentException("ContactNumber not Valid");
		}
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "UserDetail [UserId=" + UserId + ", UserName=" + UserName + ", Password=" + Password + ", FirstName="
				+ FirstName + ", LastName=" + LastName + ", ContactNumber=" + ContactNumber + ", emailId=" + emailId + "]";
	}

	// public static void main(String[] args) throws InvalidNameException {
	// UserDetail u = new UserDetail("mkomsdfsfsjnb", null, null, null, null, null);
	// }

}
