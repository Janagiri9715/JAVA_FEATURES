package com.testing.user;


public class InvalidNameException extends Exception {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return getMessage();
	}

	public InvalidNameException() {
		super();
	}

	public InvalidNameException(String msg) {
		super(msg);
	}

}
