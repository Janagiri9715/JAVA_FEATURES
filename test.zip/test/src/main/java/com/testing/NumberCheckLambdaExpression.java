package com.testing;

public class NumberCheckLambdaExpression {

	@FunctionalInterface
	public interface NumberCheck {

		boolean check(int number);
	}

	public static void main(String[] args) {
		
		NumberCheck gg = (number) -> number % 2 == 0;
		System.out.println(gg.check(21));
		

	}

}
