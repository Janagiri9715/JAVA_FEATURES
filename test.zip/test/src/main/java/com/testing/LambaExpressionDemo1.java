package com.testing;


public class LambaExpressionDemo1 {

	public static void main(String[] args) {

		I2 ii = () -> {
			System.out.println("hello from lamda");
		};
		// ii.test();
		ii.test2();


		I2 i = new I2Impl() {

//			@Override
//			public boolean test() {
//				// TODO Auto-generated method stub
//				System.out.println("Hello from Test");
//				return true;
//			}
			
			@Override
			public void test() {
				// TODO Auto-generated method stub
				System.out.println("Hello from Test");
//				return true;
			}

//			@Override
//			public void test2() {
//				// TODO Auto-generated method stub
//				System.out.println("Hello from Test overridden");
//			}
		};
		// i.test();
		// i.test2();

	}
}

	@FunctionalInterface
	interface I2 {

		public void test();

		public default void test2() {
			System.out.println("Hello from Test 2");
		}
	}

	class I2Impl implements I2 {

		// @Override
		// public boolean test() {
		// // TODO Auto-generated method stub
		// System.out.println("Hello from Test");
		// return true;
		// }
		@Override
		public void test() {
			// TODO Auto-generated method stub
			System.out.println("Hello from Test");
			// return true;
		}

		@Override
		public void test2() {
			// TODO Auto-generated method stub
			System.out.println("Hello from Test overridden");
			// I2.super.test2();
		}
	}

