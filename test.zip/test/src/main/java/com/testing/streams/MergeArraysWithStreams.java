package com.testing.streams;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MergeArraysWithStreams {

	public static void main(String[] args) {
		// Case : 1

		// Merge the two arrays into one stream, sort and collect into a List
		String[] a = { "Jana", "Giri" };
		String[] b = { "Siva", "Mani" };

		List<String> mergedSortedList = Stream.concat(Arrays.stream(a), Arrays.stream(b)) // Convert to Integer streams
																																											// and merge
				.sorted(Comparator.reverseOrder()) // Sort the merged stream
				.collect(Collectors.toList()); // Collect the sorted stream into a List
		System.out.println("Merged and sorted list: " + mergedSortedList);

		// Case : 2

		// Merge the two arrays into one stream, sort and collect into a List
		int[] arr1 = { 1, 3, 5, 7 };
		int[] arr2 = { 2, 4, 6, 8 };

		List<Integer> mergedSortedList1 = Stream.concat(Arrays.stream(arr1).boxed(), Arrays.stream(arr2).boxed())
				// Convert to Integer streams and merge
				.sorted(Comparator.reverseOrder()) // Sort the merged stream
				.collect(Collectors.toList()); // Collect the sorted stream into a List

		System.out.println("Merged and sorted list: " + mergedSortedList1);

		// Case : 3

		// Group elements by their value and count the occurrences
		List<String> items = Arrays.asList("apple", "banana", "apple", "orange", "banana", "apple");

		Map<String, Long> duplicateCounts = items.stream()
				.collect(Collectors.groupingBy(item -> item, Collectors.counting()));

		// Print duplicate counts
		duplicateCounts.entrySet()
				.stream()
				.filter(entry -> entry.getValue() > 1) // Only consider duplicates (count > 1)
				.forEach(entry -> System.out.println(entry.getKey() + " appears " + entry.getValue() + " times"));
	}
}
