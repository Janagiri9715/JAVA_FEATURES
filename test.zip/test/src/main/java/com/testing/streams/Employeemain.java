package com.testing.streams;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Employeemain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// List<Employee> employeedetails = Arrays.asList(
		// new Employee("Rahul", 50000, "IT", 25),
		// new Employee("Rohit", 40000, "IT", 30),
		// new Employee("Raj", 30000, "IT", 35),
		// new Employee("Ravi", 80000, "IT", 40),
		// new Employee("Rahul", 90000, "IT", 45),
		// new Employee("Rohit", 100000, "IT", 50));

		List<Employee> employeedetails = Arrays.asList(
				new Employee("Rahul", 50000, "IT", 25),
				new Employee("Rohit", 40000, "IT", 30),
				new Employee("Raj", 30000, "IT", 35),
				new Employee("Ravi", 90000, "IT", 40),
				new Employee("Ravi", 90000, "IT", 40),
				new Employee("Rohit", 100000, "IT", 50));

		employeedetails.stream()
				.filter(employee -> employee.getSalary() > 50000)
				.distinct()
				.collect(Collectors.toList())
				.forEach((employee) -> System.out.println(employee.getName() + " Salary :: " + employee.getSalary()));

		Map<Employee, Long> duplicateCounts = employeedetails.stream()
				.collect(Collectors.groupingBy(employee -> employee, Collectors.counting()));

		// Print the duplicates and their counts
		duplicateCounts.entrySet()
				.stream()
				.filter(entry -> entry.getValue() > 1) // Only show duplicates (count > 1)
				.forEach(
						entry -> System.out.println(
								"Employee: " + entry.getKey().getName() + " Salary: " + entry.getKey().getSalary() + " Count: "
										+ entry.getValue()));

		// By using Map to get the name and salary

		// Map<String, Double> ss = employeedetails.stream()
		// .filter(employee -> employee.getSalary() > 50000)
		// .collect(Collectors.toMap(e -> e.getName(), e -> e.getSalary()));
		// // .forEach((a, b) -> System.out.println(a + " : " + b));

		// By using Reduce

		// double dd = employeedetails.stream()
		// .filter(employee -> employee.getSalary() > 50000)
		// .map(employee -> employee.getSalary())
		// .reduce(0.0, Double::sum);

		// employeedetails.forEach(employee -> System.out.println(employee.name));

		// Advanced Stream Operations: map, filter, and reduce
		// Scenario: Analyzing employee data for insights
		// We have a list of employees with fields like name, salary, department, and age. We want to:
		// Filter employees earning more than 50,000.
		// Transform the filtered employees into a map of names and salaries.

	}

}
