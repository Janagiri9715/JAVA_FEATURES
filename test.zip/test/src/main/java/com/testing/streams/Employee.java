package com.testing.streams;
import java.util.Objects;

public class Employee {
    String name;
    double salary;
    String department;
    int age;

    public Employee(String name, double salary, String department, int age) {
        this.name = name;
        this.salary = salary;
        this.department = department;
        this.age = age;
    }

    public String getName() { return name; }
    public double getSalary() { return salary; }
    public String getDepartment() { return department; }
    public int getAge() { return age; }

		@Override
		public boolean equals(Object o) {
			if (this == o) {
				return true;
			}
			if (o == null || getClass() != o.getClass()) {
				return false;
			}
			Employee employee = (Employee) o;
			return Double.compare(employee.salary, salary) == 0 && age == employee.age && Objects.equals(name, employee.name)
					&& Objects.equals(department, employee.department);
		}

		@Override
		public int hashCode() {
			return Objects.hash(name, salary, department, age);
		}
}

//Advanced Stream Operations: map, filter, and reduce
//Scenario: Analyzing employee data for insights
//We have a list of employees with fields like name, salary, department, and age. We want to:
//Filter employees earning more than 50,000.
//Transform the filtered employees into a map of names and salaries.
//Use reduce to calculate the total salary of the filtered employees.
//java
//Copy code