package com.testing.streams.product;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

// Scenario: Grouping products by price range and
// calculating total value per range
// We want to:
// Group products into price ranges (<50, 50-100, >100).
// Use a custom collector to compute the total
// value of products in each range.

public class CustomCollectorExample {

	public static void main(String[] args) {
		List<Product> products = Arrays.asList(
				new Product("Laptop", 1200),
				new Product("Mouse", 30),
				new Product("Keyboard", 50),
				new Product("Monitor", 200),
				new Product("Charger", 30));

		// use Sorting in asending by name

		products.stream()
				.sorted(Comparator.comparing(p -> p.getName()))
				.collect(Collectors.toList())
				.forEach(p -> System.out.println("Asending By name :: " + p.getName()));

		// use Sorting in asending by price

		products.stream()
				.sorted(Comparator.comparing(p -> p.getPrice()))
				.collect(Collectors.toList())
				.forEach(p -> System.out.println("Asending By Price:: " + p.getPrice()));

		// use Sorting in desending

		products.stream()
				.sorted(Comparator.comparing(Product::getName).reversed())
				.collect(Collectors.toList())
				.forEach(p -> System.out.println("Desending By name:: " + p.getName()));

		// use Sorting in desending by price

		products.stream()
				.sorted(Comparator.comparing(Product::getPrice).reversed())
				.collect(Collectors.toList())
				.forEach(p -> System.out.println("Desending By Price:: " + p.getPrice()));

		// Custom Collector
		Map<String, Double> priceRangeTotals = products.stream()
				.collect(
						Collectors
				.groupingBy(p->
				{
					if(p.getPrice() < 50) {
                        return "<50";
                    } else if(p.getPrice() <= 100) {
                        return "50-100";
                    } else {
                        return ">100";
                    }
					
								}, Collector.of(() -> new double[1], (a, p) -> a[0] += p.getPrice(), (a1, a2) -> {
									a1[0] += a2[0];
									return a1;
								}, a -> a[0])));

		// priceRangeTotals.forEach((k, v) -> System.out.println(k + " " + v));

		System.out.println(priceRangeTotals);
		// priceRangeTotals.forEach((a, m) -> System.out.println(a + " " + m));
		}
	
	
//		System.out.println("Total value by price range: " + priceRangeTotals);
	}
