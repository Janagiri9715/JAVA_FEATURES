package com.testing;

public class LambaExpressionDemo2 {

	public static void main(String[] args) {

		IOps ii = (int a, int b) -> a + b;
		int res = ii.add(20, 10);
		System.out.println(res);
		demo((int a, int b) -> a + b + 20);

		IOps iOps = new IOps() {

			@Override
			public int add(int a, int b) {
				return a + b;
			}
		};

	}

	public static void demo(IOps iOps) {
		System.out.println(iOps.add(200, 100));
	}
}

@FunctionalInterface
interface IOps {

	public int add(int a, int b);

}
