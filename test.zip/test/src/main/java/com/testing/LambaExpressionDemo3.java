package com.testing;

public class LambaExpressionDemo3 {

	public static void main(String[] args) {

		testing t = (int a) -> a / 7;
		int res = t.divide(21);
		System.out.println(res);
		demo((int a) -> a / 7);

		// testing iOps = new testing() {
		//
		// @Override
		// public int divide(int a) {
		// return a / 7;
		// }
		// };

	}

	public static void demo(testing t) {
		System.out.println(t.divide(7));
	}
}

@FunctionalInterface
interface testing {

	public int divide(int a);

}
