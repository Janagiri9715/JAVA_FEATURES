package com.testing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StramTest {

	public static void main(String[] args) {
		List<String> words = Arrays
				.asList("pen", "pencil", "book", "laptop", "mobile", "apple");
		List<String> result = new ArrayList<>();

		// System.out.println(System.currentTimeMillis());

		// newly added

		List<String> results = words.stream()
				.filter(word -> word.length() > 5)
				.map(word -> word.toUpperCase())
				.collect(Collectors.toList());

		// System.out.println(results);

		results.forEach(e -> System.out.println(e));
		results.stream().forEach(e -> System.out.println(e));

		// System.out.println(System.currentTimeMillis());

		// old one

		// for (String word : words) {
		// if (word.length() > 5) {
		// result.add(word.toUpperCase());
		// }
		// }
		//
		// System.out.println(result);

		// System.out.println(System.currentTimeMillis());
	}

}
