package com.testing;

public class GreeterLambdaExpression {

	@FunctionalInterface
	public interface Greeter {

		String greet(String name);
	}

	public static void main(String[] args) {
		
		Greeter gg = (name) -> name;
		System.out.println(gg.greet("Hello"));
	}

}
