package com.testing.thread;

import java.util.stream.IntStream;

public class ThreadDemo {

	public static void main(String[] args) {
		Runnable run = () -> {

			IntStream.range(1, 10).forEach((e) -> {
				try {
					Thread.sleep(1000);
					System.out.println(e + Thread.currentThread().getName());
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			});

		};
		Thread t = new Thread(run);
		t.setPriority(2);
		t.start();
		Thread t2 = new Thread(run);
		t2.setPriority(1);
		try {
			t2.join();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		t2.start();
		Thread t3 = new Thread(run);
		t3.setPriority(9);
		try {
			t3.join();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		t3.start();

		Thread.getAllStackTraces().forEach((k, v) -> {
			if (k.getThreadGroup().getName().equals("main")) {
				System.out.println(k);
			}
		});
	}

}
