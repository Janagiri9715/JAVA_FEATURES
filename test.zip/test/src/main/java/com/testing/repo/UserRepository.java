package com.testing.repo;

import java.util.List;
import java.util.Optional;

import com.testing.user.UserDetail;

public interface UserRepository {

	public UserDetail addUser(UserDetail user);

	public Optional<UserDetail> getUserById(String id);

	public Optional<List<UserDetail>> getUsers();

	public void deleteUser(String id);

	public UserDetail updateUser(String id, UserDetail user);

}
